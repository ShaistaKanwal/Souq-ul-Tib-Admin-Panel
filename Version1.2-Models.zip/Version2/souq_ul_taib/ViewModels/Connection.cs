﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace souq_ul_taib.ViewModels
{
    public class Connection
    {
        /// <NOTE>
        /// in 3 ko 1 bar top of the class declare kra hay
        /// her procedure mai declare kra hua tha
        /// aur her bar sqlCmd ka naam change tha???????????????
        /// </NOTE>
        private SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["SQLCon"].ConnectionString);
        private SqlDataAdapter sqlAdp;
        private SqlCommand sqlCmd;

        public DataTable GetSPData(String ProcedureName)
        {
            

            DataTable dt = new DataTable();
            sqlAdp = new SqlDataAdapter();
            try
            {
                sqlConn.Open();
                sqlCmd = new SqlCommand(ProcedureName, sqlConn);
                sqlAdp.SelectCommand = sqlCmd;
                lock (sqlConn)
                {
                    sqlAdp.Fill(dt);
                    dt.AcceptChanges();
                    sqlConn.Close();
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        public DataTable GetSPData(String ProcedureName, Dictionary<String, Object> Params)
        {
            try
            {
                DataTable dt = new DataTable();
                sqlAdp = new SqlDataAdapter();
                sqlCmd = new SqlCommand(ProcedureName, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandTimeout = 160;

                foreach (String key in Params.Keys)
                {
                    if (Params[key] == null)
                    {
                        sqlCmd.Parameters.Add(new SqlParameter(key, DBNull.Value));
                        continue;
                    }
                    sqlCmd.Parameters.Add(new SqlParameter(key, Params[key]));
                }
                sqlAdp.SelectCommand = sqlCmd;
                lock (sqlConn)
                {
                    sqlConn.Open();
                    sqlAdp.Fill(dt);
                    sqlConn.Close();

                    return dt;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        public DataTable GetDataFromQuery(string QueryString)
        {
            DataTable dtb = new DataTable();
            try
            {
                sqlCmd = new SqlCommand(QueryString, sqlConn);
                sqlAdp = new SqlDataAdapter(sqlCmd);

                lock (sqlConn)
                {
                    sqlConn.Open();
                    sqlAdp.Fill(dtb);
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                sqlConn.Close();
            }
            finally
            {
                sqlConn.Close();
            }

            return dtb;
        }


        public DataTable GetDataFromQuery(string QueryString, ref string ref_strErrorMsg)
        {
            DataTable dtb = new DataTable();
            try
            {
                sqlCmd = new SqlCommand(QueryString, sqlConn);
                sqlAdp = new SqlDataAdapter(sqlCmd);

                lock (sqlConn)
                {
                    sqlConn.Open();
                    sqlAdp.Fill(dtb);
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                ref_strErrorMsg = "The remote server is not responding at the moment. Please try later.";
                sqlConn.Close();
                dtb = null;
            }
            finally
            {
                sqlConn.Close();
            }

            return dtb;
        }


        public DataSet GetDataSetSPData(String ProcedureName)
        {
            try
            {
                sqlAdp = new SqlDataAdapter();
                DataSet dt = new DataSet();
                sqlCmd = new SqlCommand(ProcedureName, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Connection = sqlConn;
                sqlAdp.SelectCommand = sqlCmd;
                lock (sqlConn)
                {
                    sqlConn.Open();
                    sqlAdp.Fill(dt);
                    sqlConn.Close();
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        public bool executeQuery(string strCmd, ref string ref_strErrorMsg)
        {
            try
            {
                sqlConn.Open();
                sqlCmd = new SqlCommand(strCmd, sqlConn);
                lock (sqlConn)
                {
                    sqlCmd.ExecuteNonQuery();
                    sqlConn.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                ref_strErrorMsg = ex.ToString();
                return false;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        public DataSet GetDataSetSPData(String ProcedureName, Dictionary<String, Object> Params)
        {
            try
            {

                sqlAdp = new SqlDataAdapter();
                DataSet dt = new DataSet();
                sqlCmd = new SqlCommand(ProcedureName, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                foreach (String key in Params.Keys)
                {
                    sqlCmd.Parameters.Add(new SqlParameter(key, Params[key]));
                }
                sqlAdp.SelectCommand = sqlCmd;
                lock (sqlConn)
                {
                    sqlConn.Open();
                    sqlAdp.Fill(dt);
                    sqlConn.Close();
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public int AddDataSP(String ProcedureName, Dictionary<String, Object> Params, ref string ref_strErrorMsg)
        {
            int iReturn = 0;

            try
            {
            
                sqlCmd = new SqlCommand(ProcedureName, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                foreach (String key in Params.Keys)
                {
                    if (Params[key] == null)
                    {
                        sqlCmd.Parameters.Add(new SqlParameter(key, DBNull.Value));
                        continue;
                    }
                    sqlCmd.Parameters.Add(new SqlParameter(key, Params[key]));
                }
                lock (sqlConn)
                {
                    sqlConn.Open();
                    iReturn = Convert.ToInt32(sqlCmd.ExecuteScalar());
                    //sqlCmd.ExecuteNonQuery();
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                ref_strErrorMsg = ex.ToString();
                sqlConn.Close();
            }
            finally
            {
                sqlConn.Close();

            }
            return iReturn;
        }

        public bool AddUpdateDataSP(String ProcedureName, Dictionary<String, Object> Params, ref string ref_strErrorMsg)
        {
            bool bReturn = false;
            try
            {
       
                sqlCmd = new SqlCommand(ProcedureName, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                foreach (String key in Params.Keys)
                {
                    if (Params[key] == null)
                    {
                        sqlCmd.Parameters.Add(new SqlParameter(key, DBNull.Value));
                        continue;
                    }
                    sqlCmd.Parameters.Add(new SqlParameter(key, Params[key]));
                }
                lock (sqlConn)
                {
                    sqlConn.Open();
                    sqlCmd.ExecuteNonQuery();
                    sqlConn.Close();
                    bReturn = true;
                }
            }
            catch (Exception ex)
            {
                ref_strErrorMsg = ex.ToString();
                sqlConn.Close();
            }
            finally
            {
                sqlConn.Close();

            }
            return bReturn;
        }

        /************* List Connection Methods *******************/

        public bool ListConnectionOpen(ref SqlConnection sqlConn)
        {
            try
            {
                sqlConn.Open();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool ListExecuteQuery(string strCmd, ref SqlConnection sqlConn, ref string ref_strErrorMsg)
        {
            try
            {
                sqlCmd = new SqlCommand(strCmd, sqlConn);
                lock (sqlConn)
                {
                    sqlCmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex)
            {
                ref_strErrorMsg = ex.ToString();
                return false;
            }
            finally
            {
            }
        }

        public bool ListConnectionClose(ref SqlConnection sqlConn)
        {
            try
            {
                sqlConn.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}