﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using souq_ul_taib.Models;
using System.Data;

namespace souq_ul_taib.ViewModels
{
    public class ManufacturersViewModel: Connection
    {

        public List<Manufacturer> GetAllManugacturesr()
        {

            List<Manufacturer> manufacturers = new List<Manufacturer>();

            DataTable dtb = new DataTable();
            try
            {
                dtb = GetSPData("manufactureSelectAll");

                for (int i = 0; i < dtb.Rows.Count; i++)
                {

                    DataRow row = dtb.Rows[i];
                    Manufacturer manufacturer = new Manufacturer();

                    manufacturer.Id = int.Parse(row["id"].ToString());
                    manufacturer.Name = row["Name"].ToString();

                    manufacturers.Add(manufacturer);

                }
                
                return manufacturers;
            }
            catch (Exception ex)
            {
                return null;
            }


        }




    }
}