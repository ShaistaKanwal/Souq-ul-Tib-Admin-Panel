﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using souq_ul_taib.Models;
using souq_ul_taib.ViewModels;

namespace souq_ul_taib.Controllers
{
    public class ManufacturersController : Controller
    {
        // GET: Manufacturers


        public ActionResult ViewAll()
        {
            ManufacturersViewModel ManufacturerVM = new ManufacturersViewModel();

            List<Manufacturer> manufacturers = ManufacturerVM.GetAllManugacturesr();

            return View(manufacturers);

        }

        public ActionResult Insert()
        {
            

            ViewBag.Title = "Manufacturer Page";
            return View();
        }

        public ActionResult Update()
        {
            ViewBag.Title = "Manufacturer_Update Page";
            return View();
        }

        public ActionResult Delete()
        {
            ViewBag.Title = "Manufacturer_Delete Page";
            return View();
        }

    }
    
}