﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace souq_ul_taib.Controllers
{
    public class HomeoneController : Controller
    {

        public ActionResult IndexOne(string login)
        {
            ViewBag.Title = "Home Page";
            
                return View();
   


        }
    }
}